if __name__ == '__main__':
    import cals
import math
print(cals.add(10, cals.mul(20,30)))
