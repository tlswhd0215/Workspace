a=[]
for i in range(3):
    a.append(int(input('정수 입력?')))
print('평균:',sum(a)/3.0)