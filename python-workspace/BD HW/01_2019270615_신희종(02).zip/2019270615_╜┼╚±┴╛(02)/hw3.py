list=[]
for i in range(4):
    list.append(int(input('숫자입력: ')))
print('평균:',sum(list)/4.0)10