#include <iostream>
#include <cstring>

using namespace std;

int getdiff(char * a, char * b, int start) {
	int t = 0;
	int len = strlen(a);
	int diff = 0;
	for (t = 0; t < len; t++) if (a[t] != b[t + start]) diff++;
	return diff;
}

int main() {
	char A[51];
	char B[51];
	int i, diff, lenA, lenB, pos, temp;

	cin >> A >> B;

	lenA = strlen(A);
	lenB = strlen(B);
	diff = getdiff(A, B, 0);

	for (i = 1; i < lenB - lenA + 1; i++) {
		temp = getdiff(A, B, i);
		if (temp < diff) {
			diff = temp;
			pos = i;
		}
	}

	cout << diff << "\n";
	return 0;
}