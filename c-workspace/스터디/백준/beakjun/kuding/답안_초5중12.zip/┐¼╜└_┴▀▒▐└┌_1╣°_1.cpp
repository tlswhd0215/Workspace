#include <iostream>
#include <string>
#include <vector>
#include <algorithm>

using namespace std;

int main() {
	int n, m, i, cnt;
	string str;
	vector<string> names, duplicated;

	cin >> n >> m;

	for (i = 0; i < n + m; i++) {
		cin >> str;
		names.push_back(str);
	}

	sort(names.begin(), names.end());

	cnt = 0;
	for (i = 0; i < n + m; i++) {
		if (!names[i].compare(names[i + 1])) {
			duplicated.push_back(names[i]);
			i++;
			cnt++;
		}
	}

	cout << cnt << endl;
	for (vector<string>::iterator i = duplicated.begin(); i != duplicated.end(); i++) {
		cout << *i << endl;
	}
	return 0;
}