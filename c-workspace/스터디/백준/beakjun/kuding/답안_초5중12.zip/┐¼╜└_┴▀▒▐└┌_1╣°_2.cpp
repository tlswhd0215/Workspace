#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
using namespace std;

#define ll long long

int main() {

	cin.tie(0);
	ios::sync_with_stdio(false);

	int n; cin >> n;

	cin.ignore();
	while (n--) {
		string a, b, c, d;
		cin >> a >> b;
		c = a; d = b;
		sort(c.begin(), c.end());
		sort(d.begin(), d.end());

		cout << a << " & " << b << " are";

		if (c != d) {
			cout << " NOT";
		}
		cout << " anagrams." <<endl;
	}
	return 0;
}
